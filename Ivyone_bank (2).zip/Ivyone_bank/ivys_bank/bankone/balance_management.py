class Balance:

  def __init__(self, balance, deposit, withdraw):
    self.balance = balance
    self.deposit = deposit
    self.withdraw = withdraw

  def deposited(self, ):
    self.balance = self.balance + self.deposit

    return self.balance

  def withdrawn(self):
    self.new_balance = self.balance - self.withdraw
    return self.new_balance
"""    
def add_to_balance(request):
    plus = int(request.GET['depo'])
    call = Balance(0, plus, 0)
    call.deposit()
    return render(request,"blog/deposit.html",{"balance":call.deposit()})

def substract_from_balance(request):
    minus=int(request.GET['with'])
    call = Balance(0,0,minus)
    call.withdraw()
    return render(request,"blog/withdraw.html",{"balance":call.withdraw()})"""