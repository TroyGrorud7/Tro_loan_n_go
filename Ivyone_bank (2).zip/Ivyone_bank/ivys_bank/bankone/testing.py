lists=['1','2','3','4','5','6']
listy=[]
for list in lists:
    listy.append(list)
print(lists)
print(listy)
print(listy[-1])